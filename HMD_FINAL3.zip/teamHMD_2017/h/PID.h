/*
 * PID.h
 *
 *  Created on: 2017. 6. 29.
 *      Author: User
 */

#ifndef PID_H_
#define PID_H_




void PID_control(long double Desired_rpm);

#endif /* PID_H_ */
