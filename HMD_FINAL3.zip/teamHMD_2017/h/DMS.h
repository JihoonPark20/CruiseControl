/*
 * DMS.h
 *
 *  Created on: 2017. 6. 30.
 *      Author: User
 */

#ifndef DMS_H_
#define DMS_H_

#include "typedefinition.h"

void AEB(void);
void DMS_filter(void);
int getDMS_BOTTOM(void);
int getDMS_TOP(void);
int getDMS_RIGHT(void);
int getDMS_LEFT(void);
void Hill(void);


#endif /* DMS_H_ */
